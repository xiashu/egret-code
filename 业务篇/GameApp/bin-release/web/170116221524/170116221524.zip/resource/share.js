function share(msg)
{
	document.title = msg;
	
}